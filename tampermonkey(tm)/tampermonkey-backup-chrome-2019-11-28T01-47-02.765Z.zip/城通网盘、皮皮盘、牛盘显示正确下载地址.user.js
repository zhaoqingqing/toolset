// ==UserScript==
// @id           ctfile@405647825@qq.com
// @name         城通网盘、皮皮盘、牛盘显示正确下载地址
// @namespace    http://weibo.com/pendave
// @version      0.9.5.1
// @description  This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @author       405647825@qq.com
// @include      *ctfile.com*
// @include      *ctfile.net*
// @include      *pipipan.com*
// @include      *6pan.cc/file-*html
// @include      *666pan.cc/file-*html
// @include      *777pan.cc/file-*html
// @include      *888pan.cc/file-*html
// @grant        GM_xmlhttpRequest
// @grant        GM_setClipboard
// ==/UserScript==
